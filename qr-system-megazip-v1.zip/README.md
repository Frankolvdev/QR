# QR System V1

Sistema independiente para tarjetas PVC con QR dinámico y NFC.

## Compatibilidad objetivo
- Ubuntu 20.04
- Node.js 18.20.8
- npm 10.8.2
- PM2 existente
- Nginx existente
- SQLite propio
- Puerto previsto: 4600
- Dominio previsto: qr.riandamd.com

## Regla de aislamiento
Este proyecto NO depende de MongoDB ni de `riandamd_backend` / `riandamd_app`. No requiere actualizar Node, npm, PM2 o Nginx globalmente.

## Desarrollo local
1. Copiar `.env.example` a `.env`.
2. Cambiar `SESSION_SECRET`.
3. `npm install`
4. `npm run db:generate`
5. `npm run db:push`
6. Opcional: definir `SEED_ADMIN_EMAIL` y `SEED_ADMIN_PASSWORD`.
7. `npm run db:seed`
8. `npm run dev`

## Estado V1
Incluye arquitectura inicial, SQLite/Prisma, usuarios y roles, sesiones persistentes, paneles base de administrador/vendedor y endpoint dinámico `/r/[code]`.

Aún faltan las pantallas completas de CRUD, generación/exportación de lotes QR, escáner, wizard NFC, auditoría visual y despliegue.
